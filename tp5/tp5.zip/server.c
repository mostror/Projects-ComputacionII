#include "mostronet.h"


int main(int argc, char ** argv)
{
	signal (SIGCHLD,SIG_IGN);
	int sd, csd, opcion, confd=0, j = 0, i = 0;
	pthread_t pid[20];
	int _mode = FULLSUPPORT;
	char * msg;
	struct mq_attr attr;
	serverData config;
	pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
	config.mutex = mutex;
	
	while ((opcion = getopt(argc, argv, "d:hf:46") ) >= 0)
	{
		switch(opcion)
		{
			case 'h':
				write(STDOUT_FILENO, "Usage: hist [OPTION...]\n  -h, 			     show this help and exit\n  -f <configFile>,	     uses configFile to set socket parameters, if not used default config is used\n  -4 - 6	     	Force IPv4 or IPv6 functionality\n", 249);
				return 0;

				break;

			case 'f':
				if ((confd = open(optarg, O_RDONLY)) == -1)
				{
					perror("open");
					return -3;
				}
				if (setConfig(confd, &config) < 0)
					return -1;

				break;
				
			case '4':
				if (_mode == IPV6)
				{
					printf("Options 4 & 6 called, select only one\n");
					return -2;
				}
				else
				{
					_mode = IPV4;
				}
				break;

			case '6':
				if (_mode == IPV4)
				{
					printf("Options 4 & 6 called, select only one\n");
					return -2;
				}
				else
				{
					_mode = IPV6;
				}
				break;
			
			case '?':
				write(STDERR_FILENO, "Missing file configuration path, default used\n", 46);
				break;
		}
	}

	if (confd == 0){
		if ((confd = open("tp5.conf", O_RDONLY)) == -1) 
		{
			perror("open");
			printf("Conf FAIL!\n");
			return -1;
		}
		if (setConfig(confd, &config) < 0 ){
			return -1;
		}
	}

	if((sd = mode(config, _mode)) < 0)
	{
		return -1;
	}

	attr.mq_msgsize = 5;
	mq_unlink("/serverqueue");
	if((config.mqd = mq_open("/serverqueue", O_RDWR | O_CREAT , 0666, NULL)) < 0)
	{
		perror("mqd");
		return -1;
	}
	printf("mqdParent: %d\n", config.mqd);

	for(i = 0; i < 10; i++)
	{	
		if(pthread_create(&pid[i], NULL, handle, (void *) &config) < 0)
		{
			perror("pthread_create");
			i--;
			j++;
			
			if(j == 3)
			{
				printf("thread_pool error");
				return -1;
			}
		}
			printf("creado hilo: %d\n", (int) pid[i]);
	} 



	printf("Server running, waiting for clients\n");
	msg = safemalloc(sizeof (char) * 5);
	while ((csd = accept(sd,NULL,NULL)) > 0) {
		sprintf(msg, "%d", csd);
		config.requests++;
		mq_send(config.mqd, msg, strlen(msg), 1);
		printf("new Client\n");
	}
	free(msg);
	return 0;
}

