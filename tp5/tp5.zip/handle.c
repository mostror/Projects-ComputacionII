#include "mostronet.h"


void *handle(void *arg)
{
	serverData *config = (serverData *)arg;
	struct mq_attr attr;
	char *msg;
	char buffer[2048];
	int csd = -1, leido, fd;
	char contentType[40], path[256];
	
	
	if (mq_getattr(config->mqd, &attr) < 0){
		perror("mq_getattr");
		return NULL;
	}
	msg = safemalloc(sizeof(char) * attr.mq_msgsize);
	while((mq_safereceive(config->mqd ,msg, attr.mq_msgsize, NULL, &(config->mutex))) > 0)
	{
		printf("MSG = %s soy el thread %d\n",msg, (int)pthread_self());
		csd = atoi(msg);
		if((leido = read (csd,buffer,2048)) > 0)
		{
			buffer[leido]=0;
			memset(contentType, '\0', 40);
			parser(buffer, path, contentType);
			memset(buffer, '\0', 2048);
			fd = getFile(config, path, contentType, buffer, &(config->mutex));
			
			write(csd, buffer, leido);
			if (fd > 0 || fd == -99)
			{
				printf("FD: %d\n",fd);
				while ((leido = read(fd, buffer, 1024)) > 0)
				{
					write(csd, buffer, leido);
				}
			/*	if (++reqs == REQUESTS)
				{
					shutdown(csd, SHUT_RDWR);
					close(csd);
				}*/

				memset(buffer, '\0', 2048);
				memset(path, '\0', 256);
				memset(contentType, '\0', 40);
			}
			else 
			{
				printf("ERROR:\n%s\n", buffer);
				shutdown (csd, SHUT_RDWR);
			
			}
			if(fd != -1)
			{
				if (close(fd) < 0)
				{
					perror("closeFD");
					return NULL;
				}
			}
			if(close(csd) < 0)
			{
				perror("closeCSD");
				return NULL;
			}
			//usleep(20);
			printf("client served\n");
		}
	}
	return NULL;
}
