#include "mostronet.h"

int mq_safereceive(int mqd, char *msg, size_t size,  unsigned *prio, pthread_mutex_t *mutex)
{
	int res;
	pthread_mutex_lock(mutex);
	res = mq_receive(mqd, msg, size, prio);
	pthread_mutex_unlock(mutex);
	return res;
}

